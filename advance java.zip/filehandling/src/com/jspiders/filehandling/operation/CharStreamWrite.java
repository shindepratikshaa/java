package com.jspiders.filehandling.operation;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CharStreamWrite {
	public static void main(String[] args) throws IOException {
		File file=new File("Demo.txt");
		if (file.exists()) {
			FileWriter fileWrite=new FileWriter(file);
			fileWrite.write("java is programing lang");
			System.out.println("Data is written to the file");
			fileWrite.close();
			
		}
		else {
			boolean status=file.createNewFile();
			if (status) {
				System.out.println("file is created");
				FileWriter fileWrite=new FileWriter(file);
				fileWrite.write("java is programing lang");
				System.out.println("Data is written to the file");
				fileWrite.close();
			}
			else {
				System.out.println("file is not created");
			}
		}
	}

}
