package com.jspiders.Serializationanddeserialization.object;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Serialization {
	public static void main(String[] args) throws IOException {
		File file=new File("Demo.text");
		FileOutputStream fileOutputStream=new FileOutputStream(file);
		ObjectOutputStream objectOutPutStream=new ObjectOutputStream(fileOutputStream);
		objectOutPutStream.writeObject(new User(1,"ram","ram@gmail.com",1234566778));
		System.out.println("object has been serialization");
		objectOutPutStream.close();
		fileOutputStream.close();
	}

}
