package com.jspiders.multithreading.thread;

public class MyThread1 extends Thread {
@Override
public void run() {
	System.out.println("Hello from MyThresd1");
}
}
