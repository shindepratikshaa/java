package com.jspiders.multithreading.thread;

public class MyThreads extends Thread {
     @Override
    public void run() {
    	System.out.println("Hello from myThreads");
    	System.out.println("id="+this.getId());
    	System.out.println("Name="+this.getName());
    	System.out.println("priority="+this.getPriority());
 
    	
    }
}
