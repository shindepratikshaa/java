package com.jspiders.multithreading.thread;

public class MyThread2 implements Runnable {
	
@Override
public void run() {
	System.out.println("Hello from MyThreads");
	
}
}
