package com.jspiders.multithreading.thread;

public class MyThread10 extends Thread {
	@SuppressWarnings("deprecation")
	@Override
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println("hello from mythread10");
			if(i==3) {
				stop();
		
			}
		}
		
	}
     public static void main(String[] args) {
    	 MyThread10 MyThread10=new MyThread10();
    	 MyThread10.start();
	}
}
