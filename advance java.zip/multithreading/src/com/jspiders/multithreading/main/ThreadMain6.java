package com.jspiders.multithreading.main;

import com.jspiders.multithreading.resource.MyResource1;

import com.jspiders.multithreading.thread.MyThraed8;
import com.jspiders.multithreading.thread.MyThread9;

public class ThreadMain6 {
	public static void main(String[] args) {
		MyResource1 myResource1=new MyResource1();
		
		MyThraed8 myThread8=new MyThraed8(myResource1);
		myThread8.setName("MyThraed8");


		MyThread9 myThraed9= new MyThread9(myResource1);
		myThraed9.setName("mythread9");
		myThread8.start();
		myThraed9.start();
	}

}
