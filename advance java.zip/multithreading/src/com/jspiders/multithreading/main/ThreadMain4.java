package com.jspiders.multithreading.main;

import com.jspiders.multithreading.thread.MyThreads;

public class ThreadMain4 {
	public static void main(String[] args) {
		MyThreads mythreads=new MyThreads();
		mythreads.setName("Mythreads");
		mythreads.setPriority(0);
		mythreads.start();
	
	}

}
