package com.jspiders.multithreading.resource;

public class Food {
	private boolean avaliable;
	public synchronized void order() {
		System.out.println("order is received");
		if (avaliable) {
			System.out.println("order delivered");
		}
		else {
			System.out.println("food is not available");
			System.out.println("wait for sometime...");
			
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (avaliable) {
				System.out.println("order is delivered");
			}
		}
	}
	public synchronized void prepare() {
		System.out.println("food is getting prepere");
		System.out.println("food is prepared");
		avaliable=true;
		notify();
		
	}

}
