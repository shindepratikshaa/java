package com.jspiders.multithreading.resource;

public class MyResource1 {
	public void resource() {
		System.out.println("lock is applied on resouce by" +Thread.currentThread().getName());
	}

}
