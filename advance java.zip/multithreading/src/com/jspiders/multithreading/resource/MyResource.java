package com.jspiders.multithreading.resource;

public class MyResource {
	public String resource1="Resource1";
	public String resource2="Resource2";

}
